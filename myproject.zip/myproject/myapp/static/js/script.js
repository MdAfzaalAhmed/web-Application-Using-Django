function goToForm() {
  window.location.href = urls.form;
}

function goTondex() {
  alert("Your purchasing information is recorded. We will contact you.");
  window.location.href = urls.index;
}

function goToindex() {
  alert("Thanks for contacting us... we will solve your issue shortly");
  window.location.href = urls.index;
}